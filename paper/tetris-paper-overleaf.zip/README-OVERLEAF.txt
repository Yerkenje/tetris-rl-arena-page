Overleaf package for the Tetris RL manuscript (public-safe copy)
=============================================================

This is the public-safe source package for the ISSAI FRP 2026 project page.
It contains the verified manuscript source, tables and figures. It does not
contain training code, checkpoints, raw logs or private repository history.

Contents
--------
main.tex              manuscript, at the ZIP root
references.bib        six verified references
tables/               table fragments included with \input
figures/              figure files included with \includegraphics
                      (results as PNG; two architecture diagrams as PDF)
README-OVERLEAF.txt   this note

How to compile
--------------
Use pdfLaTeX with BibTeX. Compile pdfLaTeX, BibTeX, pdfLaTeX, pdfLaTeX.
No shell escape, external fonts or external files are needed.

Status
------
The package was assembled without a TeX engine on the build machine, so no
compiled PDF is included. All \input, \includegraphics and bibliography files
are present; citations, labels and references were checked structurally.

Data provenance
---------------
The reported numbers come from the final verified result files. The research
repository is private. The public project page is:
https://yerkenje.github.io/tetris-rl-arena-page/
The results correspond to commit bf75e7c.
